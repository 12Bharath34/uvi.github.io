<?php
include "Register.php";
$dbHost = 'localhost';
$dbName = 'user';
$dbUser = 'root';
$dbPass = '';

$firstname     = filter_input(INPUT_POST, 'fname', FILTER_SANITIZE_STRING);
$lastname    = filter_input(INPUT_POST, 'lname', FILTER_SANITIZE_EMAIL);
$gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
$dob     = filter_input(INPUT_POST, 'dob', FILTER_SANITIZE_STRING);
$email    = filter_input(INPUT_POST, 'mail', FILTER_SANITIZE_EMAIL);
$password = filter_input(INPUT_POST, 'pass', FILTER_SANITIZE_STRING);
$confirm_password     = filter_input(INPUT_POST, 'cpass', FILTER_SANITIZE_STRING);
$mobile_number    = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_EMAIL);
$address = filter_input(INPUT_POST, 'addr', FILTER_SANITIZE_STRING);
$pin     = filter_input(INPUT_POST, 'pin', FILTER_SANITIZE_STRING);
$state    = filter_input(INPUT_POST, 'state', FILTER_SANITIZE_EMAIL);
$country = filter_input(INPUT_POST, 'country', FILTER_SANITIZE_STRING);
$city     = filter_input(INPUT_POST, 'city', FILTER_SANITIZE_STRING);


try {
  $db = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $stmt = $db->prepare("INSERT INTO user (name, email, password) VALUES (:name, :email, :password)");
  $stmt->bindParam(':name', $name);
  $stmt->bindParam(':email', $email);
  $stmt->bindParam(':password', $password);
  $stmt->execute();

  echo json_encode(array('success' => true));
} catch(PDOException $e) {
  echo json_encode(array('success' => false, 'error' => $e->getMessage()));
}
?>