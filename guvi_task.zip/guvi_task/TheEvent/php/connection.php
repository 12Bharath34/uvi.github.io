<?php
    $mysqlcon = mysqli_connect("localhost", "root", "", "guvi");
?>